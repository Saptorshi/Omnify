<?php echo $user->username; ?>

<ul>
	<li>Email: <?php echo $user->email; ?></li>
	<li>Number of logins: <?php echo $user->logins; ?></li>
	<li>Last Login: <?php echo Date::fuzzy_span($user->last_login); ?></li>
</ul>

<?php echo HTML::anchor('index.php/user/logout', 'Logout'); ?>
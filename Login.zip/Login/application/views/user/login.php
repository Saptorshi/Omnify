<?php if ($message) : ?>
		<?php echo $message; ?>
<?php endif; ?>

<?php echo Form::open(); ?>

<?php echo Form::label('username', 'Username'); ?>
<?php echo Form::input('username', HTML::chars(Arr::get($_POST, 'username'))); ?>

<?php echo Form::label('password', 'Password'); ?>
<?php echo Form::password('password'); ?>

<?php echo Form::label('remember', 'Remember Me'); ?>
<?php echo Form::checkbox('remember'); ?>

<?php echo Form::submit('login', 'Login'); ?>
<?php echo Form::close(); ?>

<?php echo HTML::anchor('index.php/user/create', 'create a new account'); ?>
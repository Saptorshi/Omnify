<?php if ($message) : ?>
		<?php echo $message; ?>
<?php endif; ?>

<?php echo Form::open(); ?>

<?php echo Form::label('username', 'Username'); ?>
<?php echo Form::input('username', HTML::chars(Arr::get($_POST, 'username'))); ?>

<?php echo Form::label('email', 'Email Address'); ?>
<?php echo Form::input('email', HTML::chars(Arr::get($_POST, 'email'))); ?>


<?php echo Form::label('password', 'Password'); ?>
<?php echo Form::password('password'); ?>


<?php echo Form::label('password_confirm', 'Confirm Password'); ?>
<?php echo Form::password('password_confirm'); ?>

<?php echo Form::submit('create', 'Create User'); ?>
<?php echo Form::close(); ?>

<?php echo HTML::anchor('index.php/user/login', 'login'); ?>
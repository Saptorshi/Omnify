
<title></title> 
<style type="text/css">
.error {
	color: red;
}
.message {
	padding: 10px;
	background-color: yellow;
}
</style>
</head> 
<body>
	<div id="content">
		<?php echo $content; ?>
	</div>
</body>
</html>
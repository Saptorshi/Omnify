<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2017-08-01 01:11:12 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\controller\user.php [ 16 ] in file:line
2017-08-01 01:11:12 --- NOTICE: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-08-01 21:29:00 --- EMERGENCY: ErrorException [ 8 ]: Undefined variable: message ~ APPPATH\views\user\create.php [ 5 ] in D:\wamp\www\Login\application\views\user\create.php:5
2017-08-01 21:29:00 --- NOTICE: #0 D:\wamp\www\Login\application\views\user\create.php(5): Kohana_Core::error_handler(8, 'Undefined varia...', 'D:\wamp\www\Log...', 5, Array)
#1 D:\wamp\www\Login\system\classes\Kohana\View.php(62): include('D:\wamp\www\Log...')
#2 D:\wamp\www\Login\system\classes\Kohana\View.php(359): Kohana_View::capture('D:\wamp\www\Log...', Array)
#3 D:\wamp\www\Login\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 D:\wamp\www\Login\application\views\template.php(24): Kohana_View->__toString()
#5 D:\wamp\www\Login\system\classes\Kohana\View.php(62): include('D:\wamp\www\Log...')
#6 D:\wamp\www\Login\system\classes\Kohana\View.php(359): Kohana_View::capture('D:\wamp\www\Log...', Array)
#7 D:\wamp\www\Login\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 D:\wamp\www\Login\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 D:\wamp\www\Login\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_User))
#11 D:\wamp\www\Login\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 D:\wamp\www\Login\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#13 D:\wamp\www\Login\index.php(118): Kohana_Request->execute()
#14 {main} in D:\wamp\www\Login\application\views\user\create.php:5
2017-08-01 21:29:31 --- EMERGENCY: ErrorException [ 4 ]: syntax error, unexpected T_OBJECT_OPERATOR ~ APPPATH\classes\controller\user.php [ 27 ] in file:line
2017-08-01 21:29:31 --- NOTICE: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-08-01 21:33:08 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\controller\user.php [ 75 ] in file:line
2017-08-01 21:33:08 --- NOTICE: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-08-01 21:43:24 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\controller\user.php [ 75 ] in file:line
2017-08-01 21:43:24 --- NOTICE: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-08-01 21:48:30 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\controller\user.php [ 76 ] in file:line
2017-08-01 21:48:30 --- NOTICE: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-08-01 21:52:33 --- EMERGENCY: Kohana_Exception [ 0 ]: Untrusted host localhost. If you trust localhost, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in D:\wamp\www\Login\system\classes\Kohana\URL.php:144
2017-08-01 21:52:33 --- NOTICE: #0 D:\wamp\www\Login\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, false)
#1 D:\wamp\www\Login\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('user/index', true, false)
#2 D:\wamp\www\Login\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('user/index')
#3 D:\wamp\www\Login\system\classes\Kohana\Controller.php(127): Kohana_HTTP::redirect('user/index', 302)
#4 D:\wamp\www\Login\application\classes\controller\user.php(76): Kohana_Controller::redirect('user/index')
#5 D:\wamp\www\Login\system\classes\Kohana\Controller.php(84): Controller_User->action_login()
#6 [internal function]: Kohana_Controller->execute()
#7 D:\wamp\www\Login\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_User))
#8 D:\wamp\www\Login\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 D:\wamp\www\Login\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 D:\wamp\www\Login\index.php(118): Kohana_Request->execute()
#11 {main} in D:\wamp\www\Login\system\classes\Kohana\URL.php:144
2017-08-01 21:53:07 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\controller\user.php [ 76 ] in file:line
2017-08-01 21:53:07 --- NOTICE: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2017-08-01 21:55:12 --- EMERGENCY: Kohana_Exception [ 0 ]: Untrusted host localhost. If you trust localhost, add it to the trusted hosts in the `url` config file. ~ SYSPATH\classes\Kohana\URL.php [ 107 ] in D:\wamp\www\Login\system\classes\Kohana\URL.php:144
2017-08-01 21:55:12 --- NOTICE: #0 D:\wamp\www\Login\system\classes\Kohana\URL.php(144): Kohana_URL::base(true, false)
#1 D:\wamp\www\Login\system\classes\Kohana\HTTP\Exception\Redirect.php(29): Kohana_URL::site('user/index', true, false)
#2 D:\wamp\www\Login\system\classes\Kohana\HTTP.php(40): Kohana_HTTP_Exception_Redirect->location('user/index')
#3 D:\wamp\www\Login\application\classes\Request.php(10): Kohana_HTTP::redirect('user/index')
#4 D:\wamp\www\Login\application\classes\controller\user.php(76): Request->redirect('user/index')
#5 D:\wamp\www\Login\system\classes\Kohana\Controller.php(84): Controller_User->action_login()
#6 [internal function]: Kohana_Controller->execute()
#7 D:\wamp\www\Login\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_User))
#8 D:\wamp\www\Login\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#9 D:\wamp\www\Login\system\classes\Kohana\Request.php(993): Kohana_Request_Client->execute(Object(Request))
#10 D:\wamp\www\Login\index.php(118): Kohana_Request->execute()
#11 {main} in D:\wamp\www\Login\system\classes\Kohana\URL.php:144
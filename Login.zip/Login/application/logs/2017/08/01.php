<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2017-08-01 01:11:12 --- EMERGENCY: ErrorException [ 1 ]: Call to undefined method Request::redirect() ~ APPPATH\classes\controller\user.php [ 16 ] in file:line
2017-08-01 01:11:12 --- NOTICE: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
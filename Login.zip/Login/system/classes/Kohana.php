<?php defined('SYSPATH') OR die('No direct script access.');

class Kohana extends Kohana_Core {}

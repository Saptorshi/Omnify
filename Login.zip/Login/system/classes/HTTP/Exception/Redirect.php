<?php defined('SYSPATH') OR die('No direct script access.');

abstract class HTTP_Exception_Redirect extends Kohana_HTTP_Exception_Redirect {}

<?php defined('SYSPATH') OR die('No direct script access.');

abstract class Model extends Kohana_Model {}

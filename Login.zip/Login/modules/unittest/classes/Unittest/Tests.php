<?php defined('SYSPATH') or die('No direct script access.');

class Unittest_Tests extends Kohana_Unittest_Tests {}

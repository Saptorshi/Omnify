<?php defined('SYSPATH') OR die('No direct script access.');

return array(
	// Provide the default driver to use - eg a value of Imagick will use Image_Imagick as the driver class
	// If you set a value for this config key, then the Image::$default_driver static variable that was used
	// to configure earlier versions will be ignored.
	'default_driver' => NULL,
);
